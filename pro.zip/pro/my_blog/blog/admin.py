from django.contrib import admin
from .models import Enfant
admin.site.register(Enfant)
